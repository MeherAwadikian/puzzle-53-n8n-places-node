# 🗺️ n8n Google Places Node

Custom n8n node for searching places using Google Places API, optimized for both standard workflows and AI agents.

## ✨ Features

### 🔍 Core Operations
- **Text Search**: Search places using natural language queries
- **Nearby Search**: Find places within a specified radius
- **Place Details**: Get comprehensive information about specific places

### 🤖 AI Agent Optimizations
- **AI Mode**: Optimized output format for AI agents
- **Auto Summaries**: Ready-to-use descriptions
- **Structured Data**: Simplified JSON for automated processing

### 🌍 Advanced Features
- Multi-language support (EN, FR, DE, IT, ES)
- Place type filtering
- Configurable result limits
- Robust error handling

## 🚀 Installation

### Prerequisites
1. **Google API Key**: Get a key from [Google Cloud Console](https://console.cloud.google.com/)
   - Enable the "Places API"
   - Create an API key
   - (Optional) Restrict the key to specific APIs and domains

### Node Installation
```bash
npm install @cryptodevops/n8n-nodes-google-places
```

### Development Installation
```bash
git clone <repository-url>
cd n8n-google-place-api
npm install
npm run build
npm link
```

## ⚙️ Configuration

1. **Add credentials** "Google Places API" in n8n
2. **Enter your Google API key**
3. **Use the "Google Places" node** in your workflows

## 📋 Available Operations

### 🔍 Text Search
Search for places using natural language queries.

**Parameters:**
- **Query** *(required)*: Search text (e.g., "Italian restaurants in Paris")
- **Language** *(optional)*: Result language (en, fr, de, it, es)
- **Region** *(optional)*: Region code to bias results
- **Max Results** *(optional)*: Maximum number of results (1-20)

### 📍 Nearby Search
Find places within a specified geographic area.

**Parameters:**
- **Location** *(required)*: Lat,lng coordinates (e.g., "48.8566,2.3522")
- **Radius** *(required)*: Search radius in meters
- **Type** *(optional)*: Place type (restaurant, pharmacy, hospital, etc.)
- **Language** *(optional)*: Result language
- **Region** *(optional)*: Region code
- **Max Results** *(optional)*: Maximum number of results (1-20)

### 🏪 Place Details
Get detailed information about a specific place using its Place ID.

**Parameters:**
- **Place ID** *(required)*: Unique place identifier
- **Fields** *(optional)*: Specific fields to return
- **Language** *(optional)*: Result language

### 🤖 AI Agent Mode
Enables optimization for AI agents with simplified output format.

**Additional Parameters:**
- **AI Mode**: Enables AI-optimized mode
- **Include Summary**: Includes formatted text summary

## 📤 Output Formats

### Standard Format
```json
{
  "place_id": "ChIJN1t_tDeuEmsRUsoyG83frY4",
  "name": "Restaurant Le Bernardin",
  "formatted_address": "155 West 51st Street, New York, NY 10019, USA",
  "rating": 4.5,
  "price_level": 4,
  "types": ["restaurant", "food", "establishment"],
  "geometry": {
    "location": {
      "lat": 40.7614327,
      "lng": -73.9776216
    }
  },
  "opening_hours": {
    "open_now": true,
    "weekday_text": ["Monday: 5:30 – 10:30 PM", "..."]
  }
}
```

### AI-Optimized Format
```json
{
  "name": "Restaurant Le Bernardin",
  "address": "155 West 51st Street, New York, NY 10019, USA",
  "rating": 4.5,
  "price_level": 4,
  "summary": "Upscale French seafood restaurant in Midtown Manhattan, rated 4.5/5 stars with high-end pricing. Currently open.",
  "location": {
    "lat": 40.7614327,
    "lng": -73.9776216
  },
  "timestamp": "2024-01-15T10:30:00Z"
}
```

## 📚 Documentation

- **[AI Agent Guide](./README-AI-AGENTS.md)** - Complete guide for AI agent integration
- **[AI Usage Guide](./AI-AGENT-USAGE.md)** - Practical examples and configuration
- **[Tool Configuration](./ai-tool-config.json)** - JSON configuration for AI tools

## 🔗 Useful Links

- [Google Places API Documentation](https://developers.google.com/maps/documentation/places/web-service)
- [Google Cloud Console](https://console.cloud.google.com/)
- [n8n Documentation](https://docs.n8n.io/)
- [Google Place Types](https://developers.google.com/maps/documentation/places/web-service/supported_types)

## 📄 Licence

MIT

---

**Note**: This node requires a valid Google Places API key. Pricing applies according to Google Places API usage.